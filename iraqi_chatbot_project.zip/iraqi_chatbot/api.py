from fastapi import FastAPI
from pydantic import BaseModel, Field
from chatbot_v2 import ContextChatbot

app = FastAPI(title="Iraqi Dialect Chatbot", version="1.0.0")
bot = ContextChatbot()

class ChatRequest(BaseModel):
    message: str = Field(..., min_length=1, max_length=4000)

@app.post("/chat")
def chat(request: ChatRequest):
    return bot.respond(request.message)
