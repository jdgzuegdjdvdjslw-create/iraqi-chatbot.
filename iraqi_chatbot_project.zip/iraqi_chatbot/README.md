# Iraqi Chatbot 🇮🇶

مشروع Chatbot بسيط لتصنيف الرسائل باللهجة العراقية، واختيار ردود محلية حسب الفئة المتوقعة. يتضمن نسخة سطر أوامر، ونسخة تستخدم سياق آخر ثلاث رسائل، وواجهة API باستخدام FastAPI.

> **تنبيه:** يجب تدريب النموذج أولًا قبل تشغيل `chatbot.py` أو `chatbot_v2.py` أو API. مجلد `iraqi_arabert_model/` يحتوي مبدئيًا على ملف `.gitkeep` فقط، وليس نموذجًا مدرّبًا. نتائج الاختبار والتقرير ليست نتائج تدريب فعلية إلى أن تشغّل التدريب على جهازك.

## الميزات

- 14 فئة تصنيف.
- Dataset بصيغتي JSON وCSV.
- تنظيف للنص العربي قبل التصنيف.
- نموذج AraBERT من Hugging Face مع Fine-tuning باستخدام Transformers وPyTorch.
- اختيار رد عشوائي من `responses.json`.
- حد ثقة افتراضي `0.60`، مع رد احتياطي عند انخفاض الثقة.
- سياق محدود بآخر 3 رسائل في `chatbot_v2.py`.
- API عبر FastAPI على المسار `POST /chat`.

## بنية المشروع

```text
iraqi_chatbot/
├── dataset.json
├── dataset.csv
├── train.py
├── chatbot.py
├── chatbot_v2.py
├── api.py
├── responses.json
├── requirements.txt
├── report.txt
├── output.txt
├── README.md
└── iraqi_arabert_model/
```

## المتطلبات

- Python 3.10 أو أحدث موصى به.
- اتصال بالإنترنت أول مرة لتنزيل النموذج الأساسي من Hugging Face.
- مساحة تخزين وذاكرة كافيتان لتدريب نموذج Transformer. التدريب على CPU قد يكون بطيئًا.

## التثبيت

من داخل مجلد المشروع:

```bash
python -m venv .venv
```

تفعيل البيئة الافتراضية:

**Windows:**

```powershell
.venv\Scripts\activate
```

**Linux / macOS:**

```bash
source .venv/bin/activate
```

ثم تثبيت المكتبات:

```bash
python -m pip install --upgrade pip
pip install -r requirements.txt
```

## تدريب النموذج

```bash
python train.py
```

يقوم التدريب بتحميل Dataset وتنظيفها وتقسيمها إلى تدريب وتحقق، ثم يعمل على Fine-tuning للنموذج الأساسي `aubmindlab/bert-base-arabertv02`. بعد النجاح، يُحفظ النموذج والـ tokenizer داخل `iraqi_arabert_model/`، ويُحدّث `report.txt` بمقاييس التدريب والتحقق التي نتجت عن التشغيل الفعلي.

## تشغيل نسخة CLI

بعد اكتمال التدريب:

```bash
python chatbot.py
```

اكتب `خروج` لإنهاء المحادثة.

## تشغيل نسخة السياق V2

```bash
python chatbot_v2.py
```

تستخدم هذه النسخة آخر 3 رسائل من المستخدم ضمن مدخل التصنيف، ولا تحتفظ بسياق غير محدود.

## تشغيل API

```bash
uvicorn api:app --host 0.0.0.0 --port 8000
```

توثيق API التفاعلي:

```text
http://127.0.0.1:8000/docs
```

### مثال طلب

```bash
curl -X POST "http://127.0.0.1:8000/chat" \
  -H "Content-Type: application/json" \
  -d '{"message":"هلا شلونك؟"}'
```

شكل الاستجابة المتوقع:

```json
{
  "response": "رد من ملف الردود المحلي",
  "category": "greetings",
  "confidence": 0.75
}
```

القيم أعلاه توضيحية فقط؛ التصنيف والثقة الفعليان يعتمدان على النموذج المدرّب والرسالة المدخلة.

## الفئات

`greetings`, `goodbye`, `thanks`, `how_are_you`, `food`, `football`, `weather`, `school`, `programming`, `ai`, `iraq`, `mood`, `help`, `unknown`.

## ملاحظات وحدود

- بيانات التدريب المرفقة نقطة بداية وليست ضمانًا لفهم كل تنويعات اللهجة العراقية.
- قيمة `confidence` الناتجة من Softmax ليست بالضرورة احتمالًا معايرًا للصحة.
- أي سجل سياق في API يجب فصله حسب المستخدم عند نشر الخدمة لعدة مستخدمين؛ لا تستخدم سياقًا مشتركًا بين المستخدمين في تطبيق إنتاجي.
- لا ترفع أوزان النموذج المدرّب إلى GitHub إذا كان حجمها كبيرًا؛ يمكن استخدام Git LFS أو تخزين منفصل.

## الترخيص

أضف ترخيصًا مناسبًا قبل نشر المشروع علنًا، وراجع شروط ترخيص النموذج الأساسي وبياناته قبل إعادة التوزيع.
