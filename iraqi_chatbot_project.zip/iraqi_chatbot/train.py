import json, random, re, unicodedata
from pathlib import Path
import numpy as np
import torch
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, classification_report
from transformers import AutoTokenizer, AutoModelForSequenceClassification, Trainer, TrainingArguments, set_seed

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "dataset.json"
MODEL_DIR = BASE_DIR / "iraqi_arabert_model"
MODEL_NAME = "aubmindlab/bert-base-arabertv02"
SEED = 42
MAX_LENGTH = 128
EPOCHS = 3
BATCH_SIZE = 8
LEARNING_RATE = 2e-5


def clean_text(text):
    """Normalize Arabic spelling conservatively without deleting Iraqi vocabulary."""
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = re.sub(r"[\u064B-\u065F\u0670\u06D6-\u06ED]", "", text)
    text = re.sub(r"[أإآٱ]", "ا", text)
    text = text.replace("ى", "ي").replace("ة", "ه")
    text = text.replace("ـ", "")
    text = re.sub(r"[ـ]+", "", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text

class TextDataset(torch.utils.data.Dataset):
    def __init__(self, texts, labels, tokenizer):
        self.encodings = tokenizer(texts, truncation=True, padding="max_length", max_length=MAX_LENGTH)
        self.labels = labels
    def __len__(self): return len(self.labels)
    def __getitem__(self, idx):
        item = {k: torch.tensor(v[idx], dtype=torch.long) for k, v in self.encodings.items()}
        item["labels"] = torch.tensor(self.labels[idx], dtype=torch.long)
        return item

def main():
    set_seed(SEED)
    random.seed(SEED); np.random.seed(SEED); torch.manual_seed(SEED)
    if not DATA_PATH.exists(): raise FileNotFoundError(f"Missing dataset: {DATA_PATH}")
    records = json.loads(DATA_PATH.read_text(encoding="utf-8"))
    records = [r for r in records if isinstance(r, dict) and r.get("text") and r.get("label")]
    texts = [clean_text(r["text"]) for r in records]
    labels = sorted({r["label"] for r in records})
    label2id = {label: i for i, label in enumerate(labels)}
    id2label = {i: label for label, i in label2id.items()}
    y = [label2id[r["label"]] for r in records]
    indices = np.arange(len(texts))
    train_idx, val_idx = train_test_split(indices, test_size=0.2, random_state=SEED, stratify=y)
    tokenizer = AutoTokenizer.from_pretrained(MODEL_NAME)
    model = AutoModelForSequenceClassification.from_pretrained(
        MODEL_NAME, num_labels=len(labels), label2id=label2id, id2label={i: label for i, label in id2label.items()}
    )
    train_ds = TextDataset([texts[i] for i in train_idx], [y[i] for i in train_idx], tokenizer)
    val_ds = TextDataset([texts[i] for i in val_idx], [y[i] for i in val_idx], tokenizer)
    def metrics(pred):
        logits, gold = pred
        preds = np.argmax(logits, axis=-1)
        return {"accuracy": accuracy_score(gold, preds), "f1_macro": f1_score(gold, preds, average="macro", zero_division=0)}
    args = TrainingArguments(
        output_dir=str(BASE_DIR / "training_checkpoints"), num_train_epochs=EPOCHS,
        per_device_train_batch_size=BATCH_SIZE, per_device_eval_batch_size=BATCH_SIZE,
        learning_rate=LEARNING_RATE, weight_decay=0.01, eval_strategy="epoch", save_strategy="epoch",
        logging_strategy="epoch", load_best_model_at_end=True, metric_for_best_model="f1_macro",
        greater_is_better=True, save_total_limit=2, report_to="none", seed=SEED
    )
    trainer = Trainer(model=model, args=args, train_dataset=train_ds, eval_dataset=val_ds,
                      compute_metrics=metrics, processing_class=tokenizer)
    train_result = trainer.train()
    evaluation = trainer.evaluate()
    MODEL_DIR.mkdir(parents=True, exist_ok=True)
    trainer.save_model(str(MODEL_DIR)); tokenizer.save_pretrained(str(MODEL_DIR))
    metadata = {"label2id": label2id, "id2label": {str(k): v for k, v in id2label.items()},
                "model_name": MODEL_NAME, "confidence_threshold": 0.60}
    (MODEL_DIR / "labels.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    pred_output = trainer.predict(val_ds)
    pred_ids = np.argmax(pred_output.predictions, axis=-1)
    report = ["Iraqi Arabic Chatbot Training Report", "====================================",
              f"Dataset size: {len(records)}", f"Training samples: {len(train_idx)}", f"Validation samples: {len(val_idx)}",
              f"Number of classes: {len(labels)}", f"Model: {MODEL_NAME}", f"Epochs: {EPOCHS}",
              f"Batch size: {BATCH_SIZE}", f"Learning rate: {LEARNING_RATE}",
              f"Training loss: {train_result.training_loss:.6f}", f"Validation loss: {evaluation.get('eval_loss', float('nan')):.6f}",
              f"Validation accuracy: {evaluation.get('eval_accuracy', float('nan')):.6f}",
              f"F1 score (macro): {evaluation.get('eval_f1_macro', float('nan')):.6f}", "", "Per-class validation report:",
              classification_report([y[i] for i in val_idx], pred_ids, labels=list(range(len(labels))), target_names=labels, zero_division=0),
              "Training completed successfully."]
    (BASE_DIR / "report.txt").write_text("\n".join(report), encoding="utf-8")
    print("Training complete. Model saved to", MODEL_DIR)
    print("Validation metrics:", evaluation)

if __name__ == "__main__": main()
