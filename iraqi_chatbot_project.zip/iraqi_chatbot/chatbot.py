import json, re, unicodedata, random
from pathlib import Path
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

BASE_DIR = Path(__file__).resolve().parent
MODEL_DIR = BASE_DIR / "iraqi_arabert_model"
RESPONSES_PATH = BASE_DIR / "responses.json"
CONFIDENCE_THRESHOLD = 0.60
MAX_LENGTH = 128

def clean_text(text):
    text = unicodedata.normalize("NFKC", str(text or ""))
    text = re.sub(r"[\u064B-\u065F\u0670\u06D6-\u06ED]", "", text)
    text = re.sub(r"[أإآٱ]", "ا", text).replace("ى", "ي").replace("ة", "ه").replace("ـ", "")
    return re.sub(r"\s+", " ", text).strip()

class IraqiChatbot:
    def __init__(self):
        if not MODEL_DIR.exists() or not (MODEL_DIR / "config.json").exists():
            raise FileNotFoundError("النموذج غير موجود. شغّل أولاً: python train.py")
        self.tokenizer = AutoTokenizer.from_pretrained(str(MODEL_DIR))
        self.model = AutoModelForSequenceClassification.from_pretrained(str(MODEL_DIR))
        self.model.eval()
        labels_path = MODEL_DIR / "labels.json"
        if labels_path.exists():
            metadata = json.loads(labels_path.read_text(encoding="utf-8"))
            self.id2label = {int(k): v for k, v in metadata["id2label"].items()}
        else:
            self.id2label = {int(k): v for k, v in self.model.config.id2label.items()}
        self.responses = json.loads(RESPONSES_PATH.read_text(encoding="utf-8"))
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model.to(self.device)

    def predict(self, message):
        cleaned = clean_text(message)
        if not cleaned:
            return "unknown", 0.0
        inputs = self.tokenizer(cleaned, return_tensors="pt", truncation=True, padding=True, max_length=MAX_LENGTH)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.no_grad():
            probs = torch.softmax(self.model(**inputs).logits, dim=-1)[0]
        idx = int(torch.argmax(probs).item())
        return self.id2label[idx], float(probs[idx].item())

    def respond(self, message):
        category, confidence = self.predict(message)
        if confidence < CONFIDENCE_THRESHOLD:
            return {"response": "ما فهمت عليك زين.", "category": category, "confidence": confidence}
        options = self.responses.get(category, self.responses["unknown"])
        return {"response": random.choice(options), "category": category, "confidence": confidence}

def main():
    bot = IraqiChatbot()
    print("Chatbot عراقي جاهز. اكتب 'خروج' حتى تنهي المحادثة.")
    while True:
        try: message = input("إنت: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nالبوت: مع السلامة")
            break
        if message == "خروج":
            print("البوت: الله وياك عيني")
            break
        result = bot.respond(message)
        print(f"البوت: {result['response']}  [الفئة: {result['category']} | الثقة: {result['confidence']:.3f}]")

if __name__ == "__main__": main()
