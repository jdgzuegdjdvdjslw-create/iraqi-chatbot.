IRAQI CHATBOT - QUICK START

1) Create/open the iraqi_chatbot folder and put all files in it.
2) Recommended: Python 3.10 or 3.11 and a machine with several GB RAM. Model download and fine-tuning require internet on first run.
3) Install: python -m pip install -r requirements.txt
4) Train: python train.py
5) CLI: python chatbot.py
6) Context CLI: python chatbot_v2.py
7) API: uvicorn api:app --host 0.0.0.0 --port 8000
8) Open docs: http://127.0.0.1:8000/docs

Model: aubmindlab/bert-base-arabertv02. It is an Arabic pretrained base model fine-tuned locally on this project's intent-classification dataset. The initial dataset is small for robust open-domain understanding; confidence values are softmax scores and are not guaranteed calibrated probabilities.

Context note: V2 concatenates the previous up-to-three user messages with the current message, so it uses the same classifier with contextual input; it is not a generative conversational memory model. API context is held in one in-memory bot instance shared by requests, so for multi-user deployment use per-session histories instead.
